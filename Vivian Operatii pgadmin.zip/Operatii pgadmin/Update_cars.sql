UPDATE Cars
SET color = 'Red'
WHERE car_id = 1;