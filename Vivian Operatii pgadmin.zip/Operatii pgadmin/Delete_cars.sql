DELETE FROM Cars
WHERE car_id = 2;