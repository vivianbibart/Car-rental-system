INSERT INTO Cars (make, model, year, color, plate_number)
VALUES ('Toyota', 'Camry', 2020, 'White', 'AR20BVD');

INSERT INTO Cars (make, model, year, color, plate_number)
VALUES ('Dacia', 'Logan', 2017, 'Grey', 'TM19TDV');

INSERT INTO Cars (make, model, year, color, plate_number)
VALUES ('Opel', 'Corsa', 2007, 'Black', 'TM21DRV');

INSERT INTO Cars (make, model, year, color, plate_number)
VALUES ('Alfa Romeo', 'Giulia', 2010, 'White', 'CS21NMV');
