INSERT INTO Customers (name, address, driver_license_number)
VALUES ('Dorinel Munteanu', 'Circumvalatiunii 28', '0741896520');

INSERT INTO Customers (name, address, driver_license_number)
VALUES ('Bibart Vivian', 'Aleea Brasov', '1234567890');

INSERT INTO Customers (name, address, driver_license_number)
VALUES ('Pop Maria', 'Calea Dumbravitei', '4927539817');