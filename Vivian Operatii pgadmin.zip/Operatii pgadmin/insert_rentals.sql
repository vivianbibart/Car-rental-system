INSERT INTO Rentals (start_date, end_date, car_id, customer_id)
VALUES ('2023-01-01', '2023-02-07', 1, 1);

INSERT INTO Rentals (start_date, end_date, car_id, customer_id)
VALUES ('2022-12-11', '2023-02-03', 3, 3);

INSERT INTO Rentals (start_date, end_date, car_id, customer_id)
VALUES ('2022-10-11', '2023-02-01', 4, 4);